/*
Author:       Adam Santone, PhD
Collaborator: Kassi Burns, Esq.
Co-Author:    Perplexity Labs AI 
AI Model:     dbrx-instruct
Date:         2024-04-20
*/

//global variable setup

//all koru
let k01,k02,k03,k04,k05,k06,k07,k08,k09,k10; 
let k11,k12,k13,k14,k15,k16,k17,k18,k19,k20; 
let k21,k22,k23,k24,k25,k26,k27,k28,k29,k30; 
let k31,k32,k33,k34,k35,k36,k37,k38,k39,k40; 
let k41,k42,k43,k44,k45,k46,k47,k48,k49,k50; 

//color gradient min and max 
let cMin,cMax;   

let table;    //used to hold initial data table  
let data;     //used to hold the data array
let abb = []; //state abbreviation (two-letter)
let lat = []; //latitude of state centroid
let lon = []; //longitude of state centroid
let tts = []; //total time served
let col = []; //colors based on tts
//let bgt = []; //background text
  //set up background text
  let bgt = Array(43).fill(" with liberty and justice for all");

//pre-load the data from a .csv file
function preload(){
  //contains raw lat/lon values as well as rescaled values
  table = loadTable('data/main_hd.csv', 'csv', 'header');
}

//setup function for initialization
function setup() {
  
  //read the data
  data = table.getArray();

  //push data to arrays
  //convert strings to int here
  //used R to map raw lat/lon values to new range using the 'scales' library
  for (i=0;i<data.length; i++){
    abb.push(data[i].at(0));      //this one is strings
    lon.push(int(data[i].at(6))); //longitude ('x')
    lat.push(int(data[i].at(7))); //latitutde ('y')
    tts.push(int(data[i].at(5))); //time
    col.push(map(int(data[i].at(5)),0,9000,0,255));
  }

  //set the canvas dimensions
  //1080p
  //lat/lon data are scaled for 90% of 1080p in the .csv file
  createCanvas(1920, 1080);
  
  //background gradient colors
  let colors = [color(228, 232, 216),
                color(153, 173, 166)
               ];
  
  //initialize background with colors
  bg = new GradientBackground(colors[0],colors[1]);
  
  //radius sizes
  rVal = 0.2;
  
  //angle increment values
  aInc = random(0.15,0.25);
   
  //point jitter value
  j   = 1;
  
  //create individual koru instances
  k01 = new Koru(lon[0],lat[0],rVal,tts[0],aInc,j,col[0]);    
  k02 = new Koru(lon[1],lat[1],rVal,tts[1],aInc,j,col[1]);
  k03 = new Koru(lon[2],lat[2],rVal,tts[2],aInc,j,col[2]);
  k04 = new Koru(lon[3],lat[3],rVal,tts[3],aInc,j,col[3]);
  k05 = new Koru(lon[4],lat[4],rVal,tts[4],aInc,j,col[4]);
  k06 = new Koru(lon[5],lat[5],rVal,tts[5],aInc,j,col[5]);
  k07 = new Koru(lon[6],lat[6],rVal,tts[6],aInc,j,col[6]);
  k08 = new Koru(lon[7],lat[7],rVal,tts[7],aInc,j,col[7]);
  k09 = new Koru(lon[8],lat[8],rVal,tts[8],aInc,j,col[8]);    
  k10 = new Koru(lon[9],lat[9],rVal,tts[9],aInc,j,col[9]);
  //
  k11 = new Koru(lon[10],lat[10],rVal,tts[10],aInc,j,col[10]); 
  k12 = new Koru(lon[11],lat[11],rVal,tts[11],aInc,j,col[11]);
  k13 = new Koru(lon[12],lat[12],rVal,tts[12],aInc,j,col[12]);
  k14 = new Koru(lon[13],lat[13],rVal,tts[13],aInc,j,col[13]);
  k15 = new Koru(lon[14],lat[14],rVal,tts[14],aInc,j,col[14]);
  k16 = new Koru(lon[15],lat[15],rVal,tts[15],aInc,j,col[15]);
  k17 = new Koru(lon[16],lat[16],rVal,tts[16],aInc,j,col[16]);
  k18 = new Koru(lon[17],lat[17],rVal,tts[17],aInc,j,col[17]);
  k19 = new Koru(lon[18],lat[18],rVal,tts[18],aInc,j,col[18]);
  k20 = new Koru(lon[19],lat[19],rVal,tts[19],aInc,j,col[19]);
  //
  k21 = new Koru(lon[20],lat[20],rVal,tts[20],aInc,j,col[20]); 
  k22 = new Koru(lon[21],lat[21],rVal,tts[21],aInc,j,col[21]);
  k23 = new Koru(lon[22],lat[22],rVal,tts[22],aInc,j,col[22]);
  k24 = new Koru(lon[23],lat[23],rVal,tts[23],aInc,j,col[23]);
  k25 = new Koru(lon[24],lat[24],rVal,tts[24],aInc,j,col[24]);
  k26 = new Koru(lon[25],lat[25],rVal,tts[25],aInc,j,col[25]);
  k27 = new Koru(lon[26],lat[26],rVal,tts[26],aInc,j,col[26]);
  k28 = new Koru(lon[27],lat[27],rVal,tts[27],aInc,j,col[27]);
  k29 = new Koru(lon[28],lat[28],rVal,tts[28],aInc,j,col[28]);
  k30 = new Koru(lon[29],lat[29],rVal,tts[29],aInc,j,col[29]);
  //
  k31 = new Koru(lon[30],lat[30],rVal,tts[30],aInc,j,col[30]); 
  k32 = new Koru(lon[31],lat[31],rVal,tts[31],aInc,j,col[31]);
  k33 = new Koru(lon[32],lat[32],rVal,tts[32],aInc,j,col[32]);
  k34 = new Koru(lon[33],lat[33],rVal,tts[33],aInc,j,col[33]);
  k35 = new Koru(lon[34],lat[34],rVal,tts[34],aInc,j,col[34]);
  k36 = new Koru(lon[35],lat[35],rVal,tts[35],aInc,j,col[35]);
  k37 = new Koru(lon[36],lat[36],rVal,tts[36],aInc,j,col[36]);
  k38 = new Koru(lon[37],lat[37],rVal,tts[37],aInc,j,col[37]);
  k39 = new Koru(lon[38],lat[38],rVal,tts[38],aInc,j,col[38]);
  k40 = new Koru(lon[39],lat[39],rVal,tts[39],aInc,j,col[39]);
  //
  k41 = new Koru(lon[40],lat[40],rVal,tts[40],aInc,j,col[40]); 
  k42 = new Koru(lon[41],lat[41],rVal,tts[41],aInc,j,col[41]);
  k43 = new Koru(lon[42],lat[42],rVal,tts[42],aInc,j,col[42]);
  k44 = new Koru(lon[43],lat[43],rVal,tts[43],aInc,j,col[43]);
  k45 = new Koru(lon[44],lat[44],rVal,tts[44],aInc,j,col[44]);
  k46 = new Koru(lon[45],lat[45],rVal,tts[45],aInc,j,col[45]);
  k47 = new Koru(lon[46],lat[46],rVal,tts[46],aInc,j,col[46]);
  k48 = new Koru(lon[47],lat[47],rVal,tts[47],aInc,j,col[47]);
  k49 = new Koru(lon[48],lat[48],rVal,tts[48],aInc,j,col[48]);
  k50 = new Koru(lon[49],lat[49],rVal,tts[49],aInc,j,col[49]);
}

//draw function called each frame
function draw() {
  
  //recording
  //https://www.npmjs.com/package/p5.capture/v/1.2.0

  /*
  if (frameCount === 1) {
    const capture = P5Capture.getInstance();
    capture.start({
      format: "mp4",
      framerate:30,
      width: 1920,
      height: 1080,
      duration: 1800, //60s * 30fps 
      disableUi: true
    });
  }
  */

  //set the background color
  background(220);
  bg.display();

  //shift everything to the middle
  push();  //add to stack 
  translate(width/2,height/2);
  scale(1, -1); //negative is 'reverse' axis

  //update koru
  k01.update(); k02.update(); k03.update(); k04.update(); k05.update(); k06.update(); k07.update(); k08.update(); k09.update(); k10.update(); 
  k11.update(); k12.update(); k13.update(); k14.update(); k15.update(); k16.update(); k17.update(); k18.update(); k19.update(); k20.update();
  k21.update(); k22.update(); k23.update(); k24.update(); k25.update(); k26.update(); k27.update(); k28.update(); k29.update(); k30.update();
  k31.update(); k32.update(); k33.update(); k34.update(); k35.update(); k36.update(); k37.update(); k38.update(); k39.update(); k40.update();
  k41.update(); k42.update(); k43.update(); k44.update(); k45.update(); k46.update(); k47.update(); k48.update(); k49.update(); k50.update();

  //display koru
  k01.display(); k02.display(); k03.display(); k04.display(); k05.display(); k06.display(); k07.display(); k08.display(); k09.display(); k10.display(); 
  k11.display(); k12.display(); k13.display(); k14.display(); k15.display(); k16.display(); k17.display(); k18.display(); k19.display(); k20.display();
  k21.display(); k22.display(); k23.display(); k24.display(); k25.display(); k26.display(); k27.display(); k28.display(); k29.display(); k30.display();
  k31.display(); k32.display(); k33.display(); k34.display(); k35.display(); k36.display(); k37.display(); k38.display(); k39.display(); k40.display();
  k41.display(); k42.display(); k43.display(); k44.display(); k45.display(); k46.display(); k47.display(); k48.display(); k49.display(); k50.display();
  pop(); //remove from stack
}