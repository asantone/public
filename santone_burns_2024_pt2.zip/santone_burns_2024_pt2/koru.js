/*
Author:       Adam Santone, PhD
Collaborator: Kassi Burns, Esq.
Co-Author:    Perplexity Labs AI 
AI Model:     dbrx-instruct
Date:         2024-04-20
*/

//create a koru-inspired spiral pattern
class Koru {
  constructor(x, y, r, m, i,j,c) {
    this.x = x;               
    this.y = y;
    this.radius = r;
    this.radiusGrowth = 0.01; 
    this.angle = 0;
    this.angleIncrement = i;
    this.minRadius = r;
    this.maxRadius = 5;
    this.history = [];
    this.maxPoints = m;
    this.jitter = j;
    this.col = c;
  }

  update() {
    //initialize jitter here for each ellipse individually
    let j = random(-this.jitter,this.jitter);
    
    //incremental updates
    this.angle += this.angleIncrement;
    this.radius += this.radiusGrowth;
    
    //oscillation
    if (this.radius > this.maxRadius || this.radius < this.minRadius) {
      this.radiusGrowth *= -1;
    }
    //position around the pivot
    this.x = this.x + cos(this.angle) * this.radius;
    this.y = this.y + sin(this.angle) * this.radius;
    
    //add jitter
    this.x += j;
    this.y += j;
    
    //use history array to remove old points
    this.history.push(createVector(this.x, this.y));
    if (this.history.length > this.maxPoints) {
      this.history.shift(); //remove points 
    }
  }

  //draw method for this class
  display() {
    //use history array for points
    for (let i = 0; i < this.history.length; i++) {
      let v = this.history[i];
      
      //ellipse style
      //extensive use of map() to connect style to position in the history array
      //older data points fade out
      stroke(100,0,100, map(i, 0, this.history.length, 0, 100));       //border color and opacity
      strokeWeight(map(i, 0, this.history.length, 1, 3));              //border weight
      fill(this.col, 180, 158,map(i, 0, this.history.length, 0, 100)); //main color and opacity
      circle(v.x, v.y,map(i, 0, this.history.length, 1, this.col/10)); //point shape, position, and radius
    }
  }
}