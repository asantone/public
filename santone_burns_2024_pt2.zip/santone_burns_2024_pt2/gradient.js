// adapted from gradient background by evebdn
// https://editor.p5js.org/evebdn/sketches/O9G35ueZv
class GradientBackground {
  constructor(cMin,cMax) {
    this.cMin = cMin;
    this.cMax = cMax;
  }

  display() {
    for(let y=0; y<height; y++){
      let n = map(y,0,height,0,1);
      let color_new = lerpColor(this.cMin,this.cMax,n);
      stroke(color_new);
      line(0,y,width,y);
    }
  }
}